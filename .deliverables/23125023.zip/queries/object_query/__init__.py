"""
Module queries.object_query
"""
from queries.object_query.object_query import ObjectQuery