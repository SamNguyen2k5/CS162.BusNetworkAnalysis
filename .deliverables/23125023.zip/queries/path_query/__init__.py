"""
Module queries.path_query
"""
from queries.path_query.path_query import PathQuery