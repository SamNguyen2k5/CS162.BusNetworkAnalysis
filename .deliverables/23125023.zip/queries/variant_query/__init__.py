"""
Module queries.variant_query
"""
from queries.variant_query.variant_query import VariantQuery