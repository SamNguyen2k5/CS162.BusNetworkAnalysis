from network.shortest_paths.contraction_hierarchies.periodic_ED \
    import NetworkContractionHierarchiesPeriodicED
from network.shortest_paths.contraction_hierarchies.lazy_ED \
    import NetworkContractionHierarchiesLazyED
from network.shortest_paths.contraction_hierarchies.random \
    import NetworkContractionHierarchiesRandom