"""
Module network.
Contains 
- Generic Network class, implementing a network with basic searching methods.
"""
from network.network import Network