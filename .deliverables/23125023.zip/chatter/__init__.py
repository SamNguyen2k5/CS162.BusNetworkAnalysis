"""
module chatter
"""
import os
from chatter.chatter import Chatter

os.environ['OPENAI_API_KEY'] = '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'